/**
 * Fidelly Prospect Receiver
 * Google Apps Script Web App
 *
 * Crée automatiquement :
 * My Drive / Fidelly Prospection / Fidelly Prospects
 *
 * Onglets :
 * - Prospects : base dédupliquée par SIRET
 * - Runs      : historique des exécutions
 *
 * Configuration:
 * Apps Script > Project Settings > Script Properties
 * WEBHOOK_TOKEN = votre_secret
 * FOLDER_NAME = Fidelly Prospection
 * SPREADSHEET_NAME = Fidelly Prospects
 */

const DEFAULT_FOLDER_NAME = 'Fidelly Prospection';
const DEFAULT_SPREADSHEET_NAME = 'Fidelly Prospects';

const HEADERS = [
  'priority','score','zone','keyword',
  'name','legal_name','address','postcode','city',
  'siret','siren','naf','employees','creation_date',
  'open_establishments','total_establishments','company_status',
  'website','email','email_source','phone',
  'instagram','facebook','tiktok','linkedin',
  'loyalty','loyalty_evidence',
  'osm_match_name','osm_match_score','osm_id','osm_display_name',
  'enrichment_source',
  'google_rating','google_reviews',
  'latitude','longitude','score_details',
  'first_seen','last_seen'
];

function doGet() {
  return json_({
    ok: true,
    service: 'Fidelly Prospect Receiver',
    message: 'Webhook actif'
  });
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    const props = PropertiesService.getScriptProperties();
    const expectedToken = props.getProperty('WEBHOOK_TOKEN') || '';

    if (!expectedToken) {
      return json_({ok:false, message:'WEBHOOK_TOKEN non configuré dans Script Properties'});
    }

    if ((body.token || '') !== expectedToken) {
      return json_({ok:false, message:'Token invalide'});
    }

    const rows = Array.isArray(body.rows) ? body.rows : [];
    if (!rows.length) {
      return json_({ok:false, message:'Aucune ligne reçue'});
    }

    const folderName = props.getProperty('FOLDER_NAME') || DEFAULT_FOLDER_NAME;
    const spreadsheetName = props.getProperty('SPREADSHEET_NAME') || DEFAULT_SPREADSHEET_NAME;

    const folder = getOrCreateFolder_(folderName);
    const ss = getOrCreateSpreadsheet_(folder, spreadsheetName);

    const prospects = getOrCreateSheet_(ss, 'Prospects');
    const runs = getOrCreateSheet_(ss, 'Runs');

    ensureProspectHeaders_(prospects);
    ensureRunHeaders_(runs);

    const now = new Date();
    const result = upsertProspects_(prospects, rows, now);

    runs.appendRow([
      now,
      body.source || 'unknown',
      body.generated_at || '',
      rows.length,
      result.inserted,
      result.updated,
      ss.getUrl()
    ]);

    formatSheets_(prospects, runs);

    return json_({
      ok: true,
      message: `${result.inserted} ajoutés, ${result.updated} mis à jour`,
      spreadsheetUrl: ss.getUrl(),
      folderName: folderName
    });

  } catch (err) {
    return json_({
      ok: false,
      message: String(err && err.stack ? err.stack : err)
    });
  }
}

function getOrCreateFolder_(name) {
  const root = DriveApp.getRootFolder();
  const it = root.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  return root.createFolder(name);
}

function getOrCreateSpreadsheet_(folder, name) {
  const files = folder.getFilesByName(name);
  while (files.hasNext()) {
    const file = files.next();
    if (file.getMimeType() === MimeType.GOOGLE_SHEETS) {
      return SpreadsheetApp.openById(file.getId());
    }
  }

  const ss = SpreadsheetApp.create(name);
  const file = DriveApp.getFileById(ss.getId());
  folder.addFile(file);

  // Retire de My Drive root quand possible.
  try {
    DriveApp.getRootFolder().removeFile(file);
  } catch (e) {}

  return ss;
}

function getOrCreateSheet_(ss, name) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  return sheet;
}

function ensureProspectHeaders_(sheet) {
  const current = sheet.getLastColumn()
    ? sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0]
    : [];

  const needsHeader = sheet.getLastRow() === 0 || current[0] !== HEADERS[0];

  if (needsHeader) {
    sheet.clear();
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
  }
}

function ensureRunHeaders_(sheet) {
  const headers = [
    'run_at','source','generated_at','rows_received',
    'inserted','updated','spreadsheet_url'
  ];

  if (sheet.getLastRow() === 0) {
    sheet.getRange(1,1,1,headers.length).setValues([headers]);
  }
}

function upsertProspects_(sheet, incomingRows, now) {
  const values = sheet.getDataRange().getValues();
  const header = values[0] || HEADERS;

  const col = {};
  header.forEach((h, i) => col[h] = i);

  const existingBySiret = {};
  for (let r = 1; r < values.length; r++) {
    const siret = String(values[r][col['siret']] || '').trim();
    if (siret) existingBySiret[siret] = r + 1;
  }

  const inserts = [];
  let updated = 0;

  incomingRows.forEach(obj => {
    const siret = String(obj.siret || '').trim();
    const target = new Array(HEADERS.length).fill('');

    HEADERS.forEach((h, i) => {
      if (h === 'first_seen' || h === 'last_seen') return;
      let v = obj[h];
      if (v === undefined || v === null) v = '';
      target[i] = v;
    });

    target[col['last_seen']] = now;

    if (siret && existingBySiret[siret]) {
      const rowNumber = existingBySiret[siret];
      const previousFirstSeen = sheet.getRange(rowNumber, col['first_seen'] + 1).getValue();
      target[col['first_seen']] = previousFirstSeen || now;

      sheet.getRange(rowNumber, 1, 1, HEADERS.length).setValues([target]);
      updated++;
    } else {
      target[col['first_seen']] = now;
      inserts.push(target);
    }
  });

  if (inserts.length) {
    sheet.getRange(
      sheet.getLastRow() + 1,
      1,
      inserts.length,
      HEADERS.length
    ).setValues(inserts);
  }

  return {inserted: inserts.length, updated: updated};
}

function formatSheets_(prospects, runs) {
  prospects.setFrozenRows(1);
  runs.setFrozenRows(1);

  prospects.getRange(1,1,1,prospects.getLastColumn())
    .setFontWeight('bold')
    .setBackground('#1F4E78')
    .setFontColor('#FFFFFF');

  runs.getRange(1,1,1,runs.getLastColumn())
    .setFontWeight('bold')
    .setBackground('#1F4E78')
    .setFontColor('#FFFFFF');

  if (prospects.getLastRow() > 1) {
    prospects.getRange(2,1,prospects.getLastRow()-1,prospects.getLastColumn())
      .setVerticalAlignment('top');
  }

  prospects.autoResizeColumns(1, prospects.getLastColumn());
  runs.autoResizeColumns(1, runs.getLastColumn());

  // Limites visuelles pour les colonnes longues
  const longColumns = ['address','website','email_source','instagram','facebook','score_details'];
  const header = prospects.getRange(1,1,1,prospects.getLastColumn()).getValues()[0];

  longColumns.forEach(name => {
    const idx = header.indexOf(name);
    if (idx >= 0) prospects.setColumnWidth(idx + 1, 220);
  });
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
